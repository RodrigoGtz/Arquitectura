/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

import java.util.Random;

/**
 *
 * @author Israel
 */
public class Canias {
    String canias;
    int puntos;
    public String lanzarCanias()
    {
        canias="";
        puntos=0;
        int res;
        for(int x=0;x<5;x++)
        {
            res=obtenerCania();
            canias+=res;
            puntos+=res;
            if (puntos==5) {
                puntos =10;
            }
        }
        return canias;
    }
    
    public int obtenerCania()
    {
        Random r = new Random();
        return r.nextInt(2);
    }
    
    public int obtenerPuntos()
    {
        return puntos;
    }
}
