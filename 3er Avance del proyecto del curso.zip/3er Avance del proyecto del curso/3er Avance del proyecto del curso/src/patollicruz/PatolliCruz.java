/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patollicruz;

import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Polygon;
import java.awt.geom.Ellipse2D;

/**
 *
 * @author Lorenzo
 */
public class PatolliCruz extends Canvas {

    int numCasillas = 7;
    Color ficha = Color.RED;

    @Override
    public void paint(Graphics g) {

        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.BLACK);
        Rectangle rect = new Rectangle();
        rect.setBounds(0, 0, this.getWidth() - 1, this.getHeight() - 1);
        g2d.draw(rect);

        //x,y es el punto donde se iniciará a dibujar el tablero
        //ancho y alto son las medidas de las casillas
        int x = 380, y = 220, ancho = 40, alto = 40;

        /* Parte Centro - Bien*/
        dibujaHorizontal(x - 80, y + 80, ancho, alto, 2, g2d);
        dibujaHorizontal(x - 80, y + 120, ancho, alto, 2, g2d);
        /* Aspa 1 - Mal*/
        dibujaVerticalInvertido(x - 80, y + 40, ancho, alto, numCasillas, g2d);
        dibujaVerticalInvertidoInicial(x - 40, y + 40, ancho, alto, numCasillas, g2d);

        /* Aspa 2 - Bien*/
        dibujaHorizontalInverso(x - 120, y + 120, ancho, alto, numCasillas, g2d);
        dibujaHorizontalInversoInicial(x - 120, y + 80, ancho, alto, numCasillas, g2d);

        /* Aspa 3 - Bien*/
        dibujaVertical(x - 40, y + 160, ancho, alto, numCasillas, g2d);
        dibujaVerticalIInicial(x - 80, y + 160, ancho, alto, numCasillas, g2d);

//        /* Aspa 4 - Bien*/
        dibujaHorizontal(x, y + 80, ancho, alto, numCasillas, g2d);
        dibujaHorizontalInicial(x, y + 120, ancho, alto, numCasillas, g2d);

        /*Dibujar ficha Ejemplo*/
        g2d.setStroke(new BasicStroke(1));
        g2d.setColor(ficha);
        Ellipse2D.Double ficha = new Ellipse2D.Double(x + (ancho / 7) - 40, y + (alto / 7) + 40, ancho - (ancho / 4), alto - (alto / 4));
        g2d.fill(ficha);
        g2d.setColor(Color.BLACK);
        g2d.draw(ficha);

    }

    void dibujaHorizontal(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();
        for (int i = 0; i < cuantos; i++) {
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
            
            x += ancho;
        }
    }

    void dibujaHorizontalInicial(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();
        for (int i = 0; i < cuantos; i++) {
            if (i == 0) {
                g.setColor(Color.YELLOW);
                g.fillRect(x, y, ancho, alto);
                g.setColor(Color.BLACK);
            }
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
            x += ancho;
        }
    }

    void dibujaHorizontalInverso(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();

        for (int i = 0; i < cuantos; i++) {
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
            
            x -= ancho;
        }
    }

    void dibujaHorizontalInversoInicial(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();

        for (int i = 0; i < cuantos; i++) {
            if (i == 0) {
                g.setColor(Color.YELLOW);
                g.fillRect(x, y, ancho, alto);
                g.setColor(Color.BLACK);
            }
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
//            if (i ==cuantos-1) {
//                g.drawArc(x, y+20, alto, ancho, 90, 200);
//            }
            x -= ancho;
        }
    }

    void dibujaVertical(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();
        for (int i = 0; i < cuantos-1; i++) {
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
            if (i == cuantos-2) {
                g.drawArc(x-40, y+20, ancho*2, alto, 180, 180);
            }
            y += alto;
        }
    }

    void dibujaVerticalIInicial(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();
        for (int i = 0; i < cuantos-1; i++) {
            if (i == 0) {
                g.setColor(Color.YELLOW);
                g.fillRect(x, y, ancho, alto);
                g.setColor(Color.BLACK);
            }
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
//            if (i == cuantos-1) {
//                g.drawArc(x, y+20, ancho, alto, 180, 180);
//            }
            y += alto;
        }
    }

    void dibujaVerticalInvertido(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();
        for (int i = 0; i < cuantos-1; i++) {
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
            if (i == cuantos-2) {
                g.drawArc(x, y-20, ancho*2, alto, 360, 180);
            }
            y -= alto;
        }
    }

    void dibujaVerticalInvertidoInicial(int x, int y, int ancho, int alto, int cuantos, Graphics2D g) {
        Rectangle rect = new Rectangle();
        for (int i = 0; i < cuantos-1; i++) {
            if (i == 0) {
                g.setColor(Color.YELLOW);
                g.fillRect(x, y, ancho, alto);
                g.setColor(Color.BLACK);
            }
            rect.setBounds(x, y, ancho, alto);
            g.draw(rect);
//            if (i == cuantos-1) {
//                g.drawArc(x, y-20, ancho, alto, 360, 180);
//            }
            y -= alto;
        }
    }

    public void setNumCasillas(int num) {
        this.numCasillas = num;
    }

    public void setColorFicha(Color color) {
        this.ficha = color;
    }
}
